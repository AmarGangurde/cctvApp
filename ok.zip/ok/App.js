import * as React from 'react';
import { View, Text, SafeAreaView, StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

//Pages

import Landingpage from './pages/landingPage'
import Signinpage from './pages/signinPage'
import Signuppage from './pages/signupPage'
import Userpage from './pages/userPage'

const Stack = createNativeStackNavigator();

function App() {
  return (
    <SafeAreaView style={{ flex: 2 }}>
      <StatusBar barStyle="dark-content" backgroundColor="transparent" translucent />
      <NavigationContainer>
      <Stack.Navigator>
      <Stack.Screen
         name="Landing"
         component={Landingpage}
         options={{ title: 'Overview', headerShown: false }}
         />
       <Stack.Screen
         name="Signin"
         component={Signinpage}
         options={{ title: 'Overview', headerShown: false }}
         />
       <Stack.Screen
         name="Signup"
         component={Signuppage}
         options={{ title: 'Overview', headerShown: false }}
         />
         <Stack.Screen
         name="User"
         component={Userpage}
         options={{ title: 'Overview', headerShown: false }}
         />
       
      </Stack.Navigator>
    </NavigationContainer>
  </SafeAreaView>
  );
}

export default App;